import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Tugas, PercobaanUlangan } from '../../types';
import { X, Award, CheckCircle2, MessageSquare, FileCheck2 } from 'lucide-react';

interface EssayGradingModalProps {
  task: Tugas;
  studentName: string;
  attempt: PercobaanUlangan;
  onClose: () => void;
  onSuccess: () => void;
}

export const EssayGradingModal: React.FC<EssayGradingModalProps> = ({
  task,
  studentName,
  attempt,
  onClose,
  onSuccess,
}) => {
  const { getSoalForTask, jawabanSoal, gradeEssayPercobaan } = useApp();

  const allQuestions = getSoalForTask(task.id, task.mapel_id);
  const essayQuestions = allQuestions.filter(q => q.tipe_soal === 'essay');
  const objectiveQuestions = allQuestions.filter(q => q.tipe_soal !== 'essay');
  const attemptAnswers = jawabanSoal.filter(j => j.percobaan_id === attempt.id);

  const [scores, setScores] = useState<Record<string, number>>(() => {
    const init: Record<string, number> = {};
    essayQuestions.forEach(q => {
      const existing = attemptAnswers.find(a => a.soal_id === q.id);
      init[q.id] = existing?.poin_diperoleh || 0;
    });
    return init;
  });

  const [komentar, setKomentar] = useState<string>('Telah dinilai lengkap oleh guru.');

  const handleScoreChange = (soalId: string, poin: number, maxPoin: number) => {
    const valid = Math.min(maxPoin, Math.max(0, poin));
    setScores(prev => ({ ...prev, [soalId]: valid }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const essayScores = essayQuestions.map(q => ({ soalId: q.id, poin: scores[q.id] || 0 }));
    gradeEssayPercobaan(attempt.id, essayScores, komentar);
    onSuccess();
  };

  const objectiveCorrectCount = objectiveQuestions.filter(q => {
    const ans = attemptAnswers.find(a => a.soal_id === q.id);
    return ans?.benar === true;
  }).length;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
          <div className="flex items-center space-x-2">
            <Award className="w-5 h-5 text-amber-500" />
            <h3 className="font-bold text-slate-900 text-base">Periksa Jawaban Essay</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs text-slate-700 mb-4 space-y-1">
          <p>
            <span className="font-bold text-slate-900">Nama Murid:</span> {studentName}
          </p>
          <p className="truncate">
            <span className="font-bold text-slate-900">Ulangan:</span> {task.judul}
          </p>
          {objectiveQuestions.length > 0 && (
            <p className="flex items-center space-x-1.5 pt-1 text-emerald-700 font-semibold">
              <FileCheck2 className="w-3.5 h-3.5" />
              <span>
                Soal Pilihan Ganda / Benar-Salah: {objectiveCorrectCount}/{objectiveQuestions.length} benar
                (skor otomatis {attempt.nilai_otomatis}/100 — sudah dinilai sistem, tidak perlu diubah)
              </span>
            </p>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-5 text-xs">
          {essayQuestions.length === 0 ? (
            <p className="text-slate-500 italic">Ulangan ini tidak memiliki soal essay.</p>
          ) : (
            essayQuestions.map((q, idx) => {
              const jawabanMurid = attemptAnswers.find(a => a.soal_id === q.id)?.jawaban_murid || '';
              return (
                <div key={q.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <p className="font-bold text-slate-800">
                    Soal Essay #{idx + 1} <span className="text-slate-400 font-normal">(maks {q.bobot_poin} poin)</span>
                  </p>
                  <p className="text-slate-700 whitespace-pre-line">{q.teks_soal}</p>

                  <div className="p-3 bg-white border border-slate-200 rounded-lg">
                    <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">Jawaban Murid:</p>
                    <p className="text-slate-800 whitespace-pre-line">
                      {jawabanMurid || <span className="italic text-slate-400">(Tidak diisi)</span>}
                    </p>
                  </div>

                  <div className="flex items-center space-x-2 pt-1">
                    <label className="font-bold text-slate-700">Poin Diberikan:</label>
                    <input
                      type="number"
                      min={0}
                      max={q.bobot_poin}
                      value={scores[q.id] ?? 0}
                      onChange={e => handleScoreChange(q.id, Number(e.target.value), q.bobot_poin)}
                      className="w-24 px-3 py-1.5 border border-slate-200 rounded-lg font-extrabold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    />
                    <span className="text-slate-400">/ {q.bobot_poin}</span>
                  </div>
                </div>
              );
            })
          )}

          <div>
            <label className="block font-bold text-slate-700 mb-1 flex items-center space-x-1">
              <MessageSquare className="w-3.5 h-3.5 text-slate-500" />
              <span>Komentar & Feedback Guru</span>
            </label>
            <textarea
              rows={3}
              required
              placeholder="Berikan masukan untuk murid terkait jawaban essay-nya..."
              value={komentar}
              onChange={e => setKomentar(e.target.value)}
              className="w-full px-3 py-2 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:outline-none"
            />
          </div>

          <div className="pt-3 border-t border-slate-100 flex justify-end space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 text-slate-700 font-bold rounded-xl"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl shadow transition flex items-center space-x-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Simpan Nilai Essay & Finalisasi</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
