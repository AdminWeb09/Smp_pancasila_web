import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Tugas, User, SoalUlangan, PercobaanUlangan } from '../../types';
import {
  Clock,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  X,
  Lock,
  Flag,
  Infinity as InfinityIcon,
} from 'lucide-react';

interface LmsExamRunnerModalProps {
  task: Tugas;
  student: User;
  onClose: () => void;
  /** Dipanggil sekali setelah ujian berhasil disubmit ke sistem (untuk toast/notifikasi di komponen induk) */
  onSubmitted?: (attempt: PercobaanUlangan) => void;
}

// Fisher-Yates shuffle — tidak mengubah array asli
function shuffleArray<T>(arr: T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

export const LmsExamRunnerModal: React.FC<LmsExamRunnerModalProps> = ({
  task,
  student,
  onClose,
  onSubmitted,
}) => {
  const { getSoalForTask, submitPercobaanUlangan, percobaanUlangan } = useApp();

  // Cek jumlah percobaan yang sudah dipakai murid untuk ulangan ini
  const previousAttempts = percobaanUlangan.filter(
    p => p.ulangan_id === task.id && p.murid_id === student.id
  );
  const maksPercobaan = task.maks_percobaan ?? 1; // default 1x jika tidak diatur guru
  const isUnlimited = maksPercobaan === 0;
  const attemptLimitReached = !isUnlimited && previousAttempts.length >= maksPercobaan;

  // Susun & (opsional) acak soal — hanya dihitung sekali saat modal dibuka
  const questions = useMemo<SoalUlangan[]>(() => {
    const base = getSoalForTask(task.id, task.mapel_id);
    const soalAcak = task.acak_urutan_soal !== false; // default true
    const pilihanAcak = task.acak_urutan_pilihan !== false; // default true

    const ordered = soalAcak ? shuffleArray(base) : [...base];

    return ordered.map(q => {
      if (q.tipe_soal === 'pilihan_ganda' && q.pilihan_jawaban && pilihanAcak) {
        return { ...q, pilihan_jawaban: shuffleArray(q.pilihan_jawaban) };
      }
      return q;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const waktuMulai = useMemo(() => new Date().toISOString(), []);

  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [flagged, setFlagged] = useState<Record<string, boolean>>({});

  const hasTimer = !!task.durasi_menit && task.durasi_menit > 0;
  const [timeLeft, setTimeLeft] = useState<number>(hasTimer ? (task.durasi_menit as number) * 60 : 0);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [result, setResult] = useState<PercobaanUlangan | null>(null);

  const currentQuestion = questions[currentIndex];

  const formatTimer = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleFinalSubmit = () => {
    if (isSubmitting || isSubmitted) return;
    setIsSubmitting(true);

    const responses = questions.map(q => ({
      soalId: q.id,
      jawaban: answers[q.id] || '',
    }));

    setTimeout(() => {
      const attempt = submitPercobaanUlangan(task.id, student.id, responses, waktuMulai);
      setResult(attempt);
      setIsSubmitting(false);
      setIsSubmitted(true);
      onSubmitted?.(attempt);
    }, 800);
  };

  // Timer effect — hanya berjalan kalau ujian ini punya batas waktu
  useEffect(() => {
    if (!hasTimer || isSubmitted || attemptLimitReached) return;

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleFinalSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hasTimer, isSubmitted, attemptLimitReached]);

  const handleSelectAnswer = (soalId: string, value: string) => {
    setAnswers(prev => ({ ...prev, [soalId]: value }));
  };

  const toggleFlag = (soalId: string) => {
    setFlagged(prev => ({ ...prev, [soalId]: !prev[soalId] }));
  };

  const answeredCount = questions.filter(q => (answers[q.id] || '').trim().length > 0).length;
  const flaggedCount = Object.values(flagged).filter(Boolean).length;

  // --- Tampilan: batas percobaan sudah habis ---
  if (attemptLimitReached && !isSubmitted) {
    return (
      <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-slate-800 p-6 rounded-3xl border border-slate-700 shadow-2xl space-y-4 text-center text-slate-100">
          <div className="w-14 h-14 bg-rose-500/20 text-rose-400 rounded-full mx-auto flex items-center justify-center border border-rose-500/40">
            <Lock className="w-8 h-8" />
          </div>
          <h2 className="text-lg font-black">Kesempatan Ujian Sudah Habis</h2>
          <p className="text-xs text-slate-400 leading-relaxed">
            Ulangan "{task.judul}" hanya boleh dikerjakan maksimal {maksPercobaan}x, dan kamu sudah
            memakai semua kesempatan itu ({previousAttempts.length}x). Hubungi guru mapel jika kamu
            merasa ini keliru.
          </p>
          <button
            onClick={onClose}
            className="w-full py-3 bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs rounded-xl transition"
          >
            Tutup
          </button>
        </div>
      </div>
    );
  }

  if (!currentQuestion && !isSubmitted) {
    return (
      <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-slate-800 p-6 rounded-3xl border border-slate-700 shadow-2xl space-y-4 text-center text-slate-100">
          <p className="text-sm">Belum ada soal untuk ulangan ini. Hubungi guru mapel kamu.</p>
          <button
            onClick={onClose}
            className="w-full py-3 bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs rounded-xl transition"
          >
            Tutup
          </button>
        </div>
      </div>
    );
  }

  const tampilkanHasil = task.tampilkan_hasil_setelah_selesai !== false; // default true

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex flex-col overflow-hidden animate-in fade-in duration-200">
      {/* Top Bar Navigation Header */}
      <header className="bg-slate-900 border-b border-slate-800 px-4 py-3 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-600 rounded-xl shadow-md text-white font-black text-xs tracking-wider">
            CBT LMS
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-[10px] font-bold text-blue-400 bg-blue-950 px-2 py-0.5 rounded border border-blue-800">
                SMP PANCASILA KRIAN
              </span>
              <span className="text-[10px] font-extrabold text-amber-300 bg-amber-950 px-2 py-0.5 rounded border border-amber-800">
                {task.jenis} ({task.bobot_nilai}%)
              </span>
            </div>
            <h1 className="font-extrabold text-sm sm:text-base text-slate-100 mt-0.5">{task.judul}</h1>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          {hasTimer ? (
            <div
              className={`px-3.5 py-1.5 rounded-xl border flex items-center space-x-2 shadow-inner font-mono text-sm font-bold ${
                timeLeft < 600
                  ? 'bg-rose-950/80 text-rose-300 border-rose-800 animate-pulse'
                  : 'bg-slate-800 text-emerald-400 border-slate-700'
              }`}
            >
              <Clock className="w-4 h-4" />
              <span>Sisa Waktu: {formatTimer(timeLeft)}</span>
            </div>
          ) : (
            <div className="px-3.5 py-1.5 rounded-xl border bg-slate-800 text-slate-400 border-slate-700 flex items-center space-x-2 text-[11px] font-bold">
              <InfinityIcon className="w-4 h-4" />
              <span>Tanpa Batas Waktu</span>
            </div>
          )}

          <div className="hidden lg:flex items-center space-x-1 text-[11px] text-slate-400 bg-slate-800/60 px-3 py-1.5 rounded-xl border border-slate-700">
            <Lock className="w-3.5 h-3.5 text-blue-400" />
            <span>
              Percobaan ke-{previousAttempts.length + 1}
              {!isUnlimited ? ` dari ${maksPercobaan}` : ' (tak terbatas)'}
            </span>
          </div>

          {!isSubmitted && (
            <button
              onClick={() => {
                if (confirm('Apakah Anda yakin ingin keluar dari ruang ujian? Jawaban yang belum dikirim tidak akan tersimpan.')) {
                  onClose();
                }
              }}
              className="p-2 bg-slate-800 hover:bg-rose-900/50 text-slate-400 hover:text-rose-300 rounded-xl transition"
              title="Keluar Ruang Ujian"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </header>

      {/* Main Content Area */}
      {!isSubmitted ? (
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          <main className="flex-1 overflow-y-auto p-4 md:p-6 bg-slate-900 text-slate-100 flex flex-col justify-between">
            <div className="space-y-6 max-w-3xl mx-auto w-full">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center space-x-2">
                  <span className="bg-blue-600 text-white font-black text-xs px-3 py-1 rounded-lg">
                    Soal No. {currentIndex + 1}
                  </span>
                  <span className="text-xs font-semibold text-slate-400 bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-700">
                    {currentQuestion.tipe_soal === 'pilihan_ganda'
                      ? 'Pilihan Ganda'
                      : currentQuestion.tipe_soal === 'benar_salah'
                      ? 'Benar / Salah'
                      : 'Soal Essay / Uraian'}
                  </span>
                </div>

                <button
                  onClick={() => toggleFlag(currentQuestion.id)}
                  className={`flex items-center space-x-1.5 px-3 py-1 rounded-lg text-xs font-bold transition border ${
                    flagged[currentQuestion.id]
                      ? 'bg-amber-500 text-slate-950 border-amber-400'
                      : 'bg-slate-800 text-slate-400 hover:text-slate-200 border-slate-700'
                  }`}
                >
                  <Flag className="w-3.5 h-3.5" />
                  <span>{flagged[currentQuestion.id] ? 'Ragu-Ragu (Aktif)' : 'Tandai Ragu-Ragu'}</span>
                </button>
              </div>

              <div className="p-5 bg-slate-800/80 border border-slate-700/80 rounded-2xl shadow-sm text-sm sm:text-base leading-relaxed text-slate-100">
                <p className="whitespace-pre-line">{currentQuestion.teks_soal}</p>
              </div>

              {currentQuestion.tipe_soal === 'pilihan_ganda' && (
                <div className="space-y-3 pt-2">
                  <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Pilih Jawaban:</p>
                  <div className="grid grid-cols-1 gap-2.5">
                    {currentQuestion.pilihan_jawaban?.map(opt => {
                      const isSelected = answers[currentQuestion.id] === opt.key;
                      return (
                        <button
                          key={opt.key}
                          onClick={() => handleSelectAnswer(currentQuestion.id, opt.key)}
                          className={`p-4 rounded-xl text-left text-sm font-medium transition flex items-center space-x-3 border ${
                            isSelected
                              ? 'bg-blue-600/20 border-blue-500 text-white shadow-md'
                              : 'bg-slate-800/60 hover:bg-slate-800 text-slate-300 border-slate-700'
                          }`}
                        >
                          <span
                            className={`w-8 h-8 rounded-lg flex items-center justify-center font-black text-xs border ${
                              isSelected
                                ? 'bg-blue-600 text-white border-blue-400'
                                : 'bg-slate-700 text-slate-300 border-slate-600'
                            }`}
                          >
                            {opt.key}
                          </span>
                          <span className="flex-1">{opt.teks}</span>
                          {isSelected && <CheckCircle2 className="w-5 h-5 text-blue-400" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {currentQuestion.tipe_soal === 'benar_salah' && (
                <div className="space-y-3 pt-2">
                  <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Pilih Jawaban:</p>
                  <div className="grid grid-cols-2 gap-3">
                    {['Benar', 'Salah'].map(opt => {
                      const isSelected = answers[currentQuestion.id] === opt;
                      return (
                        <button
                          key={opt}
                          onClick={() => handleSelectAnswer(currentQuestion.id, opt)}
                          className={`p-4 rounded-xl text-center text-sm font-bold transition border ${
                            isSelected
                              ? 'bg-blue-600/20 border-blue-500 text-white shadow-md'
                              : 'bg-slate-800/60 hover:bg-slate-800 text-slate-300 border-slate-700'
                          }`}
                        >
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {currentQuestion.tipe_soal === 'essay' && (
                <div className="space-y-3 pt-2">
                  <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Tuliskan Jawaban Uraian / Essay:</p>
                  <textarea
                    rows={6}
                    value={answers[currentQuestion.id] || ''}
                    onChange={e => handleSelectAnswer(currentQuestion.id, e.target.value)}
                    placeholder="Ketikkan uraian langkah penyelesaian atau penjelasan jawaban Anda di sini..."
                    className="w-full p-4 bg-slate-800 border border-slate-700 rounded-xl text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 placeholder-slate-500"
                  />
                  <p className="text-[10px] text-slate-500 italic">
                    Soal essay tidak dinilai otomatis — jawabanmu akan diperiksa manual oleh guru.
                  </p>
                </div>
              )}
            </div>

            {/* Bottom Footer Navigation */}
            <div className="mt-8 pt-4 border-t border-slate-800 flex items-center justify-between max-w-3xl mx-auto w-full">
              <button
                disabled={currentIndex === 0}
                onClick={() => setCurrentIndex(prev => prev - 1)}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-slate-200 font-bold text-xs rounded-xl transition flex items-center space-x-1.5"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Sebelumnya</span>
              </button>

              <span className="text-xs text-slate-400 font-medium">
                {currentIndex + 1} dari {questions.length} Soal
              </span>

              {currentIndex < questions.length - 1 ? (
                <button
                  onClick={() => setCurrentIndex(prev => prev + 1)}
                  className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl transition flex items-center space-x-1.5 shadow"
                >
                  <span>Selanjutnya</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  onClick={handleFinalSubmit}
                  disabled={isSubmitting}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl transition flex items-center space-x-2 shadow-lg animate-pulse"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isSubmitting ? 'Mengirim...' : 'Selesaikan & Kumpulkan Ujian'}</span>
                </button>
              )}
            </div>
          </main>

          {/* Right Sidebar: Student & Question Palette Grid */}
          <aside className="w-full md:w-80 bg-slate-950 border-t md:border-t-0 md:border-l border-slate-800 p-4 overflow-y-auto flex flex-col justify-between space-y-6">
            <div className="space-y-5">
              <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-2xl flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-blue-600/30 border border-blue-500 flex items-center justify-center font-black text-blue-300 text-sm shrink-0">
                  {student.nama.charAt(0)}
                </div>
                <div className="min-w-0 flex-1">
                  <h4 className="font-extrabold text-xs text-slate-200 truncate">{student.nama}</h4>
                  <p className="text-[10px] text-slate-400">NISN: {student.nip_nisn || '-'}</p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-extrabold text-slate-300">Navigasi Soal</span>
                  <span className="text-[11px] font-bold text-emerald-400">
                    {answeredCount}/{questions.length} Terisi
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-1.5 text-[10px] text-slate-400">
                  <div className="flex items-center space-x-1.5">
                    <span className="w-2.5 h-2.5 rounded bg-emerald-500"></span>
                    <span>Sudah Terisi</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <span className="w-2.5 h-2.5 rounded bg-amber-400"></span>
                    <span>Ragu-Ragu ({flaggedCount})</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <span className="w-2.5 h-2.5 rounded bg-blue-600"></span>
                    <span>Soal Aktif</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <span className="w-2.5 h-2.5 rounded bg-slate-800 border border-slate-700"></span>
                    <span>Belum Dijawab</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-5 gap-2">
                {questions.map((q, idx) => {
                  const isCurrent = idx === currentIndex;
                  const isAns = (answers[q.id] || '').trim().length > 0;
                  const isFlg = flagged[q.id];

                  let bgClass = 'bg-slate-800 text-slate-400 hover:bg-slate-700 border-slate-700';
                  if (isFlg) {
                    bgClass = 'bg-amber-400 text-slate-950 font-extrabold border-amber-300';
                  } else if (isAns) {
                    bgClass = 'bg-emerald-600 text-white font-extrabold border-emerald-500';
                  }
                  if (isCurrent) {
                    bgClass += ' ring-2 ring-blue-400 ring-offset-2 ring-offset-slate-950';
                  }

                  return (
                    <button
                      key={q.id}
                      onClick={() => setCurrentIndex(idx)}
                      className={`h-10 rounded-xl font-bold text-xs transition flex items-center justify-center border shadow-sm ${bgClass}`}
                    >
                      {idx + 1}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 space-y-2">
              <button
                onClick={handleFinalSubmit}
                disabled={isSubmitting}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl transition shadow-lg flex items-center justify-center space-x-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Kumpulkan Ujian Sekarang</span>
              </button>
              <p className="text-[10px] text-center text-slate-500">
                Pilihan Ganda & Benar-Salah dinilai otomatis. Soal essay diperiksa guru.
              </p>
            </div>
          </aside>
        </div>
      ) : (
        /* Exam Completion & Digital Receipt View */
        <div className="flex-1 flex items-center justify-center p-6 bg-slate-900 text-slate-100 overflow-y-auto">
          <div className="max-w-md w-full bg-slate-800 p-6 rounded-3xl border border-slate-700 shadow-2xl space-y-6 text-center animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 rounded-full mx-auto flex items-center justify-center border border-emerald-500/40">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-1">
              <span className="text-[10px] font-extrabold uppercase tracking-widest text-emerald-400 bg-emerald-950 px-3 py-1 rounded-full border border-emerald-800">
                Ujian Berhasil Dikirim
              </span>
              <h2 className="text-xl font-black text-white pt-2">Bukti Pengumpulan Ujian</h2>
              <p className="text-xs text-slate-400">SMP PANCASILA KRIAN — SIDOARJO</p>
            </div>

            <div className="p-4 bg-slate-900/80 rounded-2xl border border-slate-700 space-y-3 text-left">
              <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800">
                <span className="text-slate-400">Siswa / Peserta:</span>
                <span className="font-extrabold text-white">{student.nama}</span>
              </div>
              <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800">
                <span className="text-slate-400">Ujian / Evaluasi:</span>
                <span className="font-bold text-amber-300">{task.judul}</span>
              </div>

              {tampilkanHasil ? (
                <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800">
                  <span className="text-slate-400">Skor Otomatis (PG & B-S):</span>
                  <span className="font-black text-emerald-400 text-sm">
                    {result?.nilai_otomatis ?? 0} / 100
                  </span>
                </div>
              ) : (
                <div className="flex justify-between items-center text-xs pb-2 border-b border-slate-800">
                  <span className="text-slate-400">Skor:</span>
                  <span className="font-bold text-slate-400 text-xs">Disembunyikan oleh guru</span>
                </div>
              )}

              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">Status Pemeriksaan:</span>
                <span className="font-bold text-slate-200 text-[11px]">
                  {result?.status_pemeriksaan === 'menunggu_pemeriksaan_guru'
                    ? 'Menunggu Guru Periksa Essay'
                    : 'Selesai (Otomatis)'}
                </span>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed italic">
              {result?.status_pemeriksaan === 'menunggu_pemeriksaan_guru'
                ? 'Jawaban Pilihan Ganda/Benar-Salah telah dikoreksi otomatis. Jawaban essay telah diteruskan ke guru pengampu untuk penilaian akhir — nilai final akan muncul setelah guru selesai memeriksa.'
                : 'Seluruh soal telah dikoreksi otomatis oleh sistem.'}
            </p>

            <button
              onClick={onClose}
              className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-xs rounded-xl shadow-lg transition"
            >
              Tutup & Kembali ke Daftar Ujian
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
